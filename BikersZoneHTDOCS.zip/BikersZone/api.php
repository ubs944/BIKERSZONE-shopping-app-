<?php
//include 'connection.php';

$con=mysqli_connect('localhost','root','','bikerszone',3306);
$result=array();
if(isset($_GET['action']))
{
	extract($_GET);
    if($action=="login")
    {   $q="select * from login where username='$uname' and password='$password'";
         $res=mysqli_query($con,$q);


         if(mysqli_num_rows($res)>0)
         {
        	$ar=array();

        	while($row=mysqli_fetch_array($res))
            {
        		 array_push($ar,$row);
        	}

        	$result['status']="success";
        	$result['data']=$ar;
         }
         else
        {
        	$result['status']="failed";

        }

        echo json_encode($result);
        die();
    }


    
    elseif($action=="checkemail")
    {   $q="select * from login inner join publicuser using (loginId) where username='$uname' and email='$email'";
         $res=mysqli_query($con,$q);


         if(mysqli_num_rows($res)>0)
         {
        	$ar=array();

        	while($row=mysqli_fetch_array($res))
            {
        		 array_push($ar,$row);
        	}

        	$result['status']="success";
        	
         }
         else
        {
        	$result['status']="failed";

        }

        echo json_encode($result);
        die();
    }

    elseif($action=="checkpwd")


    {    $q="update login set password='$password' where loginId=(select loginId from publicuser where email='$email')";
         mysqli_query($con,$q);


         $result['status']="success";


        echo json_encode($result);
        die();
    }

    elseif($action=="register")
    {
        $q="select * from login inner join publicuser using (loginId) where username='$uname' or email='$email'";
        $res=mysqli_query($con,$q);
        if(mysqli_num_rows($res)> 0)
        {
            $result['status']="duplicate";
        }
        else
        {
            $t1="insert into login(username,password)values('$uname','$password')";
            $lid=mysqli_query($con,$t1);

             $t="INSERT INTO `publicuser` VALUES(NULL,(select max(loginId) from login),'$email')";
            mysqli_query($con,$t);


            $result['status']="success";
        }

         echo json_encode($result);
        die();


    }

    elseif($action=="viewallcommunity")
    {

          $q="SELECT * FROM `community` ";
        $res=mysqli_query($con,$q);
        if(mysqli_num_rows($res)>0)
        {
            $ar=array();
            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";

            $result['data']=$ar;
        }else{
            $result['status']="failed";
        }
        echo json_encode($result);
        die();
    }



    elseif($action=="viewreg")
    {
        $t="SELECT * FROM `women` WHERE `log_id`='$logid'";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['data']=$ar;


        }else
        {
            $result['status']="failed";
        }
         $result['action']="viewreg";
        echo json_encode($result);
        die();
    }

    elseif($action=="viewnews")
    {
        $t="SELECT * FROM `news`";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['data']=$ar;


        }else
        {
            $result['status']="failed";
        }
         $result['action']="viewnews";
        echo json_encode($result);
        die();
    }



    elseif($action=="emergencyno")
    {

        $t="INSERT INTO `contacts` VALUES(NULL,(select women_id from women where log_id='$logid'),'$phoneno','$pname')";
        mysqli_query($con,$t);


        $result['status']="success";


         echo json_encode($result);
        die();


    }

    elseif($action=="viewhospital")
    {
        $t="SELECT `hospitals`.*,(3959 * ACOS ( COS ( RADIANS('$lati') ) * COS( RADIANS( latitude) ) * COS( RADIANS( longitude ) - RADIANS('$longi') ) + SIN ( RADIANS('$lati') ) * SIN( RADIANS( latitude ) ))) AS user_distance FROM `hospitals`HAVING user_distance  < 31.068 ORDER BY user_distance ASC";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['data']=$ar;


        }else
        {
            $result['status']="failed";
        }
         $result['action']="viewhospital";
        echo json_encode($result);
        die();
    }

    elseif($action=="viewcomplaint")
    {
        $t="SELECT * FROM `complaints` WHERE women_id =(select women_id from women where `log_id`='$logid')";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['data']=$ar;


        }else
        {
            $result['status']="failed";
        }
         $result['action']="viewcomplaint";
        echo json_encode($result);
        die();
    }

    elseif($action=="complaint")
    {

        $t="INSERT INTO `complaints` VALUES(NULL,(select women_id from women where log_id='$logid'),'$des','',curdate())";
        mysqli_query($con,$t);


        $result['status']="success";
        $result['action']="complaint";

         echo json_encode($result);
        die();


    }



    elseif($action=="viewuserfeedback")
    {
        $t="SELECT * FROM `feedback` WHERE women_id =(select women_id from women where `log_id`='$logid')";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['data']=$ar;


        }else
        {
            $result['status']="failed";
        }
         $result['action']="viewuserfeedback";
        echo json_encode($result);
        die();
    }

    elseif($action=="feedback")
    {

        $t="INSERT INTO `feedback` VALUES(NULL,(select women_id from women where log_id='$logid'),'$fback',curdate())";
        mysqli_query($con,$t);


        $result['status']="success";
        $result['action']="feedback";

         echo json_encode($result);
        die();


    }

    elseif($action=="getnumber")
    {
        $t="SELECT * FROM `contacts` WHERE women_id =(select women_id from women where `log_id`='$lid')";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['numbers']=$ar[0]['contact_no'];


        }else
        {
            $result['status']="failed";
        }
         $result['action']="getnumber";
        echo json_encode($result);
        die();
    }

    elseif($action=="viewpolice")
    {
        $t="SELECT `securityauthority`.*,(3959 * ACOS ( COS ( RADIANS('$lati') ) * COS( RADIANS( latitude) ) * COS( RADIANS( longitude ) - RADIANS('$longi') ) + SIN ( RADIANS('$lati') ) * SIN( RADIANS( latitude ) ))) AS user_distance FROM `securityauthority`HAVING user_distance  < 31.068 ORDER BY user_distance ASC";
        $res=mysqli_query($con,$t);


        if(mysqli_num_rows($res)>0){
            $ar=array();

            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";
            $result['data']=$ar;


        }else
        {
            $result['status']="failed";
        }
         $result['action']="viewpolice";
        echo json_encode($result);
        die();
    }

    elseif($action=="addcomments")
    {
        // mysqli_query($c,"INSERT INTO `comments` VALUES(NULL,'$community_id','$comment',CURDATE())");
        // $id=mysqli_insert_id($c);

         $t1="INSERT INTO `comments` values (null,'$community_id',(select puser_id from publicuser where loginId='$lid'),'$comment',curdate())";
        $lid=mysqli_query($con,$t1);


        $result['status']="success";
        $result['action']="addcomments";
        echo json_encode($result);
        die();
    }


  elseif($action=="viewcomments")
    {

        $q="SELECT * FROM `comments`,`publicuser`,`login` WHERE `comments`.`puser_id`=`publicuser`.puser_id AND `publicuser`.loginId=`login`.loginId and community_id ='$community_id'";
        $res=mysqli_query($con,$q);
        if(mysqli_num_rows($res)>0)
        {
            $ar=array();
            while($row=mysqli_fetch_array($res)){
                 array_push($ar,$row);
            }
            $result['status']="success";

            $result['data']=$ar;
        }else{
            $result['status']="failed";
        }
        $result['action']="viewcomments";
        echo json_encode($result);
        die();
    }



}
