
<?php 
$c = mysqli_connect("localhost", "root", "", "bikerszone","3306");
$result=array();

    extract($_POST);
        $fname = "Image_".date('Y_m_d_h_i_s_a').".jpg";
		move_uploaded_file($_FILES['image']['tmp_name'],"uploads/".$fname);
		$f = "uploads/".$fname;

        $t1="INSERT INTO `community` values (null,(select puser_id from publicuser where loginId='$lid'),'$name','$f','$desc',curdate())";
        $lid=mysqli_query($c,$t1);


    	// mysqli_query($c,"INSERT INTO `community` values (null,(select puser_id from publicuser where login_Id='$lid'),'$name','$f','$desc',curdate())");
        // $id=mysqli_insert_id($c);

        $result['status']="success";
         // $result['out']="INSERT INTO `programs` VALUES(NULL,(SELECT `user_id` FROM `users` WHERE `login_id`='$login_id'),'$pname','$namesss','$f','$place','$date','$time','$lati','$longi'),'$type'";
        $result['action']="uploadfile";
        echo json_encode($result);
        die();

        
        ?>