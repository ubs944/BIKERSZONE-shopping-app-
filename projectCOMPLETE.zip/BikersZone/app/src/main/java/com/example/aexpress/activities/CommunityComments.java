package com.example.aexpress.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aexpress.R;
import com.example.aexpress.utils.Constants;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

public class CommunityComments extends AppCompatActivity implements JsonResponse {

    TextView t1,t2;
    ImageView i1;
    ListView l1;
    String comment;
    SharedPreferences sh;
    String[] comments,cid,value,name;
    Button b1;
    EditText e1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_comments);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        t1=findViewById(R.id.name);
        t2=findViewById(R.id.desc);
        i1=findViewById(R.id.imageView2);
        l1=findViewById(R.id.lvchats);
        b1=findViewById(R.id.button6);
        e1=findViewById(R.id.etcmnt);

        t1.setText(CommunityView.community);
        t2.setText(CommunityView.details);

        String pth =  Constants.API_BASE_URL +"/"+CommunityView.img;
        pth = pth.replace("~", "");
//	       Toast.makeText(context, pth, Toast.LENGTH_LONG).show();

        Log.d("-------------", pth);
        Picasso.with(getApplicationContext())
                .load(pth)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background).into(i1);

        JsonReq jr = new JsonReq();
        jr.json_response = (JsonResponse) CommunityComments.this;
        String q = "api.php?action=viewcomments&community_id="+CommunityView.cid;
        q = q.replace(" ", "%20");
        jr.execute(q);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comment = e1.getText().toString();

                if (comment.equalsIgnoreCase("")) {
                    e1.setError("Enter Comment to submit");
                    e1.setFocusable(true);
                }else {

                    JsonReq jr = new JsonReq();
                    jr.json_response = (JsonResponse) CommunityComments.this;
                    String q = "api.php?action=addcomments&comment="+comment+"&community_id="+CommunityView.cid+"&lid="+sh.getString("log_id","");
                    q = q.replace(" ", "%20");
                    jr.execute(q);
                }
            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {

            String action = jo.getString("action");
//            Toast.makeText(getApplicationContext(), "Uploaded SUCCESS  action", Toast.LENGTH_LONG).show();
            Log.d("pearl", action);

            if (action.equalsIgnoreCase("addcomments")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
                    startActivity(new Intent(getApplicationContext(), CommunityComments.class));

                } else {

                    Toast.makeText(getApplicationContext(), "Something Went Wrong!", Toast.LENGTH_LONG).show();
                }
            }
            if (action.equalsIgnoreCase("viewcomments")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
                    JSONArray ja1 = (JSONArray) jo.getJSONArray("data");


                    comments = new String[ja1.length()];
                    cid = new String[ja1.length()];
                    name = new String[ja1.length()];
                    value = new String[ja1.length()];


                    for (int i = 0; i < ja1.length(); i++) {


                        comments[i] = ja1.getJSONObject(i).getString("comment");
                        cid[i] = ja1.getJSONObject(i).getString("comment_id");
                        name[i] = ja1.getJSONObject(i).getString("username");
                        value[i] = name[i]+"\n"+"\t"+comments[i];

                    }
//                ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, value);
//                l1.setAdapter(ar);
                    CustomUser a = new CustomUser(this, name,comments);
                    l1.setAdapter(a);
                }

            }

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }
}