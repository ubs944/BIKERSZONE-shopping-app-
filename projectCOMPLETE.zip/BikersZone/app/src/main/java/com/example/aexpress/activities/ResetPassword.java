package com.example.aexpress.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.aexpress.R;

import org.json.JSONObject;

public class ResetPassword extends AppCompatActivity implements JsonResponse{

    String pwd,confirmpwd;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        EditText e1 = findViewById(R.id.enternewpwd);
        EditText e2 = findViewById(R.id.confirmpwd);
        Button b1 = findViewById(R.id.resetbutton);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                pwd = e1.getText().toString();
                confirmpwd = e2.getText().toString();


                if(pwd.equalsIgnoreCase(confirmpwd)) {

                JsonReq jr = new JsonReq();
                jr.json_response = (JsonResponse) ResetPassword.this;
                String q = "api.php?action=checkpwd&password=" + pwd+"&email="+ForgotActivity.email;
                q = q.replace(" ", "%20");
                jr.execute(q);
                }else {
                    Toast.makeText(getApplicationContext(), "Password mismatch!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    @Override
    public void response(JSONObject jo) {

        try {
            String status = jo.getString("status");
            Log.d("result", status);
            //   Toast.makeText(getApplicationContext(), status,Toast.LENGTH_LONG).show();
            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(), "Password updated!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Login failed.TRY AGAIN!!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

    }
}
