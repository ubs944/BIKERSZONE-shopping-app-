package com.example.aexpress.activities;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aexpress.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements JsonResponse {

    String username,password,logid;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        TextView uname=findViewById(R.id.inputusername);
        TextView passw=findViewById(R.id.inputemail);
        TextView signin=findViewById(R.id.signup);
        TextView forgotpwd=findViewById(R.id.forgetpwd);
        Button login=findViewById(R.id.btnlogin);


//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
//            }
//        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(myIntent);
            }
        });

        forgotpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,ForgotActivity.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                username = uname.getText().toString();
                password = passw.getText().toString();

                if(username.equalsIgnoreCase("")){
                    uname.setError("Enter Username ");
                    uname.setFocusable(true);
                }
                else if (password.equalsIgnoreCase("")){

                    passw.setError("enter Password");
                    passw.setFocusable(true);
                }else {


                    JsonReq jr = new JsonReq();
                    jr.json_response = (JsonResponse) LoginActivity.this;
                    String q = "api.php?action=login&uname=" + username + "&password=" + password;
                    q = q.replace(" ", "%20");
                    jr.execute(q);

                }

//                startActivity(new Intent(LoginActivity.this,MainActivity.class));
            }
        });


    }

    @Override
    public void response(JSONObject jo) {
//        Toast.makeText(getApplicationContext(), "test", Toast.LENGTH_LONG).show();
        try {
            String status = jo.getString("status");
            Log.d("result", status);
            //   Toast.makeText(getApplicationContext(), status,Toast.LENGTH_LONG).show();
            if (status.equalsIgnoreCase("success")) {
                JSONArray ja = (JSONArray) jo.getJSONArray("data");
                logid = ja.getJSONObject(0).getString("loginId");

                //     Toast.makeText(getApplicationContext(), logid, Toast.LENGTH_LONG).show();
                //    Toast.makeText(getApplicationContext(), type, Toast.LENGTH_LONG).show();
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("log_id", logid);

                ed.commit();

                startActivity(new Intent(getApplicationContext(), MainActivity.class));



            } else
            {
                Toast.makeText(getApplicationContext(), "Login failed.TRY AGAIN!!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }
}