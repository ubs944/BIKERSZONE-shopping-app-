package com.example.aexpress.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.aexpress.R;

import org.json.JSONObject;

public class ForgotActivity extends AppCompatActivity  implements JsonResponse{

    public static  String email,uname,logid;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);

        EditText e1 = findViewById(R.id.enternewpwd);
        EditText e2 = findViewById(R.id.confirmpwd);
        Button b1 = findViewById(R.id.resetbutton);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                email = e1.getText().toString();
                uname = e2.getText().toString();

                JsonReq jr = new JsonReq();
                jr.json_response = (JsonResponse) ForgotActivity.this;
                String q = "api.php?action=checkemail&email=" + email + "&uname=" + uname;
                q = q.replace(" ", "%20");
                jr.execute(q);

            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {
            String status = jo.getString("status");
            Log.d("result", status);
            //   Toast.makeText(getApplicationContext(), status,Toast.LENGTH_LONG).show();
            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(), "Verification Comlpetd!!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), ResetPassword.class));
            }
         else
            {
                Toast.makeText(getApplicationContext(), "Login failed.TRY AGAIN!!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }
}