package com.example.aexpress.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aexpress.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity implements JsonResponse {
    TextView uname,emailid,passw,conpsswrd;
    String username,password,email,cpwd;
    Button register;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        uname=findViewById(R.id.inputusername);
        emailid=findViewById(R.id.inputemail);
        passw=findViewById(R.id.inputPassword);
        conpsswrd=findViewById(R.id.inputConfirmPassword);

        register=findViewById(R.id.btnRegister);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                username =uname.getText().toString();
                password = passw.getText().toString();
                email=emailid.getText().toString();
                cpwd=conpsswrd.getText().toString();



                 if(username.equalsIgnoreCase("")){
                    uname.setError("Enter Username ");
                    uname.setFocusable(true);
                }
                else if (!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+")) {
                    emailid.setError("Enter Your Valid EmailId");
                    emailid.setFocusable(true);
                }

                else if (password.equalsIgnoreCase("")){

                    passw.setError("enter Password");
                    passw.setFocusable(true);
                } else if (cpwd.equalsIgnoreCase("")){

                    conpsswrd.setError("Enter your Passwrd");
                     conpsswrd.setFocusable(true);
                }else {



                    if(password.equalsIgnoreCase(cpwd)){


                    JsonReq jr = new JsonReq();
                    jr.json_response = (JsonResponse) RegisterActivity.this;
                    String q = "api.php?action=register&uname=" + username + "&password=" + password + "&email=" + email ;
                    q = q.replace(" ", "%20");
                    jr.execute(q);
                    }else {
                        Toast.makeText(getApplicationContext(), "Password Mismatch!", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

       TextView alreadylogin=findViewById(R.id.alreadyregistered);

       alreadylogin.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
           }
       });


    }

    @Override
    public void response(JSONObject jo) {
        try {
            String status = jo.getString("status");
            Log.d("result", status);
            //   Toast.makeText(getApplicationContext(), status,Toast.LENGTH_LONG).show();
            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(), "Registration Successfull!!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(),LoginActivity.class));

            } else if (status.equalsIgnoreCase("duplicate")) {
                Toast.makeText(getApplicationContext(), "Username or Email Already Exist!", Toast.LENGTH_SHORT).show();
            }else
            {
                Toast.makeText(getApplicationContext(), "Login failed.TRY AGAIN!!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }
}

