package com.example.aexpress.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.aexpress.R;

public class Nearby_shops extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby_shops);
    }
}