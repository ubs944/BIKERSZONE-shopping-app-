package com.example.aexpress.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.example.aexpress.Custimage;
import com.example.aexpress.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class CommunityView extends AppCompatActivity implements JsonResponse, AdapterView.OnItemClickListener {

    ListView l1;
    ImageButton i1;

    String [] image,name,desc,com_id,value;
    public static String img,community,details,cid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_view);

        l1 = findViewById(R.id.communityview);
        l1.setOnItemClickListener(this);
        i1 = findViewById(R.id.imageButton);

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) CommunityView.this;
        String q = "api.php?action=viewallcommunity";
        JR.execute(q);
        Log.d("pearl", q);


        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),CommunityAddPost.class));
            }
        });
    }

    @Override
    public void response(JSONObject jo) {

        try {

            String status = jo.getString("status");
            Log.d("pearl", status);


            if (status.equalsIgnoreCase("success")) {
                JSONArray ja1 = (JSONArray) jo.getJSONArray("data");

                image = new String[ja1.length()];
                name = new String[ja1.length()];
                desc = new String[ja1.length()];
                com_id = new String[ja1.length()];
                value = new String[ja1.length()];

                for (int i = 0; i < ja1.length(); i++) {

                    image[i] = ja1.getJSONObject(i).getString("image");
                    name[i] = ja1.getJSONObject(i).getString("name");
                    desc[i] = ja1.getJSONObject(i).getString("desc");
                    com_id[i] = ja1.getJSONObject(i).getString("community_id");
//                    agentname[i] = ja1.getJSONObject(i).getString("agent_name");
//                    value[i] = "AgentName: " + agentname[i] + "\nPlace: " + place[i] + "\nphone: " + phone[i] + "\nlicence: " + licence[i]+ "\nlatitude: " + latitude[i] + "\nlongitude: " + longitude[i];

                }

                Custimage a = new Custimage(this, image, name,desc);
                l1.setAdapter(a);
//                ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, value);
//                l1.setAdapter(ar);
            }
        }

        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        cid=com_id[i];
        img=image[i];
        community=name[i];
        details=desc[i];
        final CharSequence[] items = {"Comments", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(CommunityView.this);
        // builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Comments")) {

                    startActivity(new Intent(getApplicationContext(),CommunityComments.class));
                }

                else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }

            }

        });
        builder.show();
    }
}