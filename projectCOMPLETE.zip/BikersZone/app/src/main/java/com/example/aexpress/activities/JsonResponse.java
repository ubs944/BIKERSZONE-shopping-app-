package com.example.aexpress.activities;

import org.json.JSONObject;

public interface JsonResponse {
	public void response(JSONObject jo);
}
